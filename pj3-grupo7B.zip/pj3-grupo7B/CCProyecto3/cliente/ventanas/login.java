package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.*;
import java.util.*;

public class login extends JPanel{
    //campos de la ventana
      JPanel contenedor;
      GridBagLayout layout;
      GridBagConstraints limite;
      public JTextField userNameTb;
      public JPasswordField userPassTb;
      public JButton logBt, clearBt, mainBt;

    //constructro de la clase e interfaz
    public login(){
      //inicializacion del layout
          layout = new GridBagLayout();
          layout.columnWidths = new int[]{0, 0};
          layout.rowHeights = new int[]{0, 0};
          layout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
          layout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
          this.setLayout(layout);
      //inicializacion del jpanel
          contenedor = new JPanel();
          contenedor.setLayout(null);
          limite = new GridBagConstraints();
          limite.fill = GridBagConstraints.BOTH;
          limite.gridx = 0;
          limite.gridy = 0;
      //campos de los textboxs
          userNameTb = new JTextField(10);
          userNameTb.setBounds(160, 170, 305, 30);
          contenedor.add(userNameTb);
          userPassTb = new JPasswordField(10);
          userPassTb.setBounds(160, 220, 305, 30);
          contenedor.add(userPassTb);
      //campos de los botones
          mainBt = new JButton("Main" ,new ImageIcon("Icons/main.png"));
          mainBt.setBounds(80, 300, 115, 45);
          contenedor.add(mainBt);
          logBt = new JButton("Login", new ImageIcon("Icons/login.png"));
          logBt.setBounds(220, 300, 115, 45);
          contenedor.add(logBt);
          clearBt = new JButton("Clear", new ImageIcon("Icons/clear.png"));
          clearBt.setBounds(360, 300, 115, 45);
          contenedor.add(clearBt);
      //campos de los labels
            JLabel mainTxt = new JLabel("Login de usuario");
            mainTxt.setFont(new Font(mainTxt.getName(),Font.PLAIN, 22));
            mainTxt.setBounds(140, 65, 280, 45);
            contenedor.add(mainTxt);
            JLabel nameTxt = new JLabel("Username: ");
            nameTxt.setBounds(68, 175, 100, 16);
            contenedor.add(nameTxt);
            JLabel ipTxt = new JLabel("Password: ");
            ipTxt.setBounds(68, 225, 100, 16);
            contenedor.add(ipTxt);
      //agrego el Jpanel al frame principal
          this.add(contenedor, limite);

      //accion del boton de clearBt
          clearBt.addActionListener((ActionEvent e) ->{
              userNameTb.setText("");
              userPassTb.setText("");
          });
    }
}
