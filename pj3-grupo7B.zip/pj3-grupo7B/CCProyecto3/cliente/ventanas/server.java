package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.*;
import java.util.*;

public class server extends JPanel{
    //campos de la ventana
      JPanel contenedor;
      GridBagLayout layout;
      GridBagConstraints limite;
      public JTextField serverNameTb, serverIpTb;
      public JButton regBt, clearBt, mainBt;

    //constructro de la clase e interfaz
    public server(){
      //inicializacion del layout
          layout = new GridBagLayout();
          layout.columnWidths = new int[]{0, 0};
          layout.rowHeights = new int[]{0, 0};
          layout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
          layout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
          this.setLayout(layout);
      //inicializacion del jpanel
          contenedor = new JPanel();
          contenedor.setLayout(null);
          limite = new GridBagConstraints();
          limite.fill = GridBagConstraints.BOTH;
          limite.gridx = 0;
          limite.gridy = 0;
      //campos de los textboxs
          serverNameTb = new JTextField(10);
          serverNameTb.setBounds(160, 170, 305, 30);
          contenedor.add(serverNameTb);
          serverIpTb = new JTextField(10);
          serverIpTb.setBounds(160, 220, 305, 30);
          contenedor.add(serverIpTb);
      //campos de los botones
          mainBt = new JButton("Main" ,new ImageIcon("Icons/main.png"));
          mainBt.setBounds(80, 300, 115, 45);
          contenedor.add(mainBt);
          regBt = new JButton("Registrar", new ImageIcon("Icons/register.png"));
          regBt.setBounds(220, 300, 115, 45);
          contenedor.add(regBt);
          clearBt = new JButton("Clear", new ImageIcon("Icons/clear.png"));
          clearBt.setBounds(360, 300, 115, 45);
          contenedor.add(clearBt);
      //campos de los labels
            JLabel mainTxt = new JLabel("Registro de servidores");
            mainTxt.setFont(new Font(mainTxt.getName(),Font.PLAIN, 22));
            mainTxt.setBounds(140, 65, 280, 45);
            contenedor.add(mainTxt);
            JLabel nameTxt = new JLabel("ServerName: ");
            nameTxt.setBounds(68, 175, 100, 16);
            contenedor.add(nameTxt);
            JLabel ipTxt = new JLabel("IP address: ");
            ipTxt.setBounds(68, 225, 100, 16);
            contenedor.add(ipTxt);
      //agrego el Jpanel al frame principal
          this.add(contenedor, limite);

      //accion del boton de clearBt
          clearBt.addActionListener((ActionEvent e) ->{
              serverNameTb.setText("");
              serverIpTb.setText("");
          });
    }
}
