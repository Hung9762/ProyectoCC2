package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.*;
import java.util.*;

public class send extends JPanel{
  //campos de la ventana
    JPanel contenedor;
    GridBagLayout layout;
    GridBagConstraints limite;
    public JButton sendBt, clearBt, contactBt, inboxBt;
    public JTextField contactTb, asuntoTb;
    public JTextArea msgTb;
    public JScrollPane scroll;

    //constructor
    public send(){
      //inicializacion del layout
          layout = new GridBagLayout();
          layout.columnWidths = new int[]{0, 0};
          layout.rowHeights = new int[]{0, 0};
          layout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
          layout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
          this.setLayout(layout);
      //inicializacion del jpanel
          contenedor = new JPanel();
          contenedor.setLayout(null);
          limite = new GridBagConstraints();
          limite.fill = GridBagConstraints.BOTH;
          limite.gridx = 0;
          limite.gridy = 0;
      //instancia de los textbox
          contactTb = new JTextField(10);
          contactTb.setBounds(135, 100, 340, 25);
          contenedor.add(contactTb);
          asuntoTb  = new JTextField(10);
          asuntoTb.setBounds(135, 150, 340, 25);
          contenedor.add(asuntoTb);
          scroll = new JScrollPane();
          scroll.setBounds(135, 210, 340, 105);
          contenedor.add(scroll);
          msgTb = new JTextArea();
          msgTb.setLineWrap(true);
          scroll.setViewportView(msgTb);
      //instancia de los botones
          clearBt = new JButton("Clear", new ImageIcon("Icons/clear.png"));
          clearBt.setBounds(335, 325, 110, 44);
          contenedor.add(clearBt);
          sendBt = new JButton("Send", new ImageIcon("Icons/send.png"));
          sendBt.setBounds(145, 325, 110, 44);
          contenedor.add(sendBt);
          contactBt = new JButton(new ImageIcon("Icons/contact.png"));
          contactBt.setBounds(30, 80, 60, 60);
          contenedor.add(contactBt);
          inboxBt = new JButton(new ImageIcon("Icons/inbox.png"));
          inboxBt.setBounds(30, 180, 60, 60);
          contenedor.add(inboxBt);
          JLabel mainTxt = new JLabel("Enviar mensaje");
          mainTxt.setFont(new Font(mainTxt.getName(),Font.PLAIN, 22));
          mainTxt.setBounds(135, 5, 280, 45);
          contenedor.add(mainTxt);
          JLabel nameTxt = new JLabel("Contactos: ");
          nameTxt.setBounds(137, 81, 61, 16);
          contenedor.add(nameTxt);
          JLabel ipTxt = new JLabel("Asuntos: ");
          ipTxt.setBounds(137, 133, 61, 16);
          contenedor.add(ipTxt);
          JLabel pTxt = new JLabel("Mensaje: ");
          pTxt.setBounds(137, 188, 61, 16);
          contenedor.add(pTxt);


      //agrego el Jpanel al frame principal
         this.add(contenedor, limite);
      //accion del boton de clearBt
         clearBt.addActionListener((ActionEvent e) ->{
            contactTb.setText("");
            asuntoTb.setText("");
         });

    }
}
