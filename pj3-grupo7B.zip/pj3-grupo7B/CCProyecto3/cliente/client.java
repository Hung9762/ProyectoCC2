import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.util.Scanner;
import ventanas.*;
import java.net.*;
import UGDB.*;



public class client{
      //base de datos tabla de servidores
      static DB baseDatos;
      //ventanas
      public static final String mainCard = "main";
      public static final String serverCard = "server";
      public static final String loginCard = "login";
      public static final String sendCard = "send";
      public static final String inboxCard = "inbox";
      public static final String contactCard = "contact";
      //campos de la intefaz grafica
      static JFrame interfaz;
      static JPanel contenedor;
      static CardLayout ventana;
      //Datos del usuario y servidor
      public static String userName, userServer, userPass, serverName, serverIp;
      //puerto de lectura y escritura
      BufferedReader clientInputSocket;
      PrintWriter clientOutputSocket;
      Socket clientSocket;
      //main
      public static void main(String args []){
          new client();
      }
      //constructor del la intefaz grafica
      public client(){
        //conexion con la base de datos de servidores disponibles
        baseDatos = new DB("serverList.db");
        try {
              baseDatos.connect();
        }catch (Exception error){
              System.out.println("Error en conexion de base de datos desde el cliente");
              error.printStackTrace();
        }
        //instancia del JFrame y del panel contenedor
          interfaz = new JFrame();
          ventana = new CardLayout();
          contenedor = new JPanel(ventana);

        //instancia de las clases de ventanadas disponibles
          main mainView = new main();
          server serverView = new server();
          login loginView = new login();
          send sendView = new send();
          contact contacView = new contact();
          inbox inboxView = new inboxView();

        //Adicion de la ventanas al CardLayout
          contenedor.add(mainView, mainCard);
          contenedor.add(serverView, serverCard);
          contenedor.add(loginView, loginCard);
          contenedor.add(sendView, sendCard);
          contenedor.add(contacView, contactCard);
          contenedor.add(inboxView, inboxCard);
//-------------- acciones de los botones de la ventana main --------------------
        //boton para ir a la ventana de registro de servidores
          mainView.serverBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                interfaz.setTitle(" Registro de servidores ");
                ventana.show(contenedor, serverCard);
            }
          });
        //boton para ir a la ventana de login del usuario
          mainView.loginBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                interfaz.setTitle(" Login ");
                ventana.show(contenedor, loginCard);
            }
          });
//------------ acciones de los botones de la ventana server --------------------
        //boton para ir a la ventana main
          serverView.mainBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                interfaz.setTitle("- Main -");
                ventana.show(contenedor, mainCard);
            }
          });
        //boton para registrar un servidor en la base de datos
        serverView.regBt.addActionListener(new ActionListener(){
          @Override
          public void actionPerformed(ActionEvent e){
                //comprobacion que los textboxs esten llenos
                if (serverView.serverNameTb.getText().equals("") || serverView.serverIpTb.getText().equals("")){
                      displayMessage(2, " No lleno todas las casillas", " ERROR INGRESO DATOS");
                }else{
                      //consultar a la base de datos si el servidor ya existe en la tabla
                      String query = "SELECT servidor FROM servers";
                      //consulta la base de datos
                        try {
                            baseDatos.connect();
                            baseDatos.executeQuery(query,"rs");
                            boolean existeServer = false;
                            while (baseDatos.next("rs")){
                                  if (baseDatos.getString("servidor","rs").equals(serverView.serverNameTb.getText())){
                                      existeServer = true;
                                      break;
                                  }
                            }
                            baseDatos.close();
                            //comparacion del resultado
                            if (existeServer != true){
                                  //ingreso de datos del servidor a la tabla
                                  try{
                                    query = "INSERT INTO `servers`(`servidor`,`ip`) VALUES ('"+ serverView.serverNameTb.getText()+"','" + serverView.serverIpTb.getText() +"')";
                                    baseDatos.connect();
                                    baseDatos.executeNonQuery(query);
                                    displayMessage(3, " Servidor Registrado ", "REGISTRO SERVIDOR");
                                    serverView.serverNameTb.setText("");
                                    serverView.serverIpTb.setText("");
                                    baseDatos.close();
                                  }catch(Exception error){
                                      error.printStackTrace();
                                  }
                            }else{
                                displayMessage(2, " El servidor ya esta registrado ", "ERROR INGRESO DATOS");
                            }

                        }catch(Exception error){
                              error.printStackTrace();
                        }

                }
          }
        });
//----------------------- Acciones de los botones de login ---------------------
              //boton para ir a la ventana main
                loginView.mainBt.addActionListener(new ActionListener(){
                  @Override
                  public void actionPerformed(ActionEvent e){
                      interfaz.setTitle("- Main -");
                      ventana.show(contenedor, mainCard);
                  }
                });
                //boton para ir a la ventana main
                loginView.logBt.addActionListener(new ActionListener(){
                  @Override
                  public void actionPerformed(ActionEvent e){
                        //metodo para separa el username del servidor
                        String [] userInfo = getUserServer(loginView.userNameTb.getText());
                        String password  = new String(loginView.userPassTb.getPassword());
                        //buscar el numero de ip del servidor del cliente
                        try {
                            baseDatos.connect();
                            String query = "SELECT ip FROM servers WHERE servidor ='" + userInfo[1] +"'";
                            baseDatos.executeQuery(query, "rs");
                            boolean result = baseDatos.next("rs");
                            if (result != false){
                                String IpServer = (String)baseDatos.getString("ip","rs");
                                //System.out.println(IpServer);
                                //abrir la conexion con el socket
                                  clientSocket = new Socket(IpServer, 1400);
                                  clientOutputSocket = new PrintWriter(clientSocket.getOutputStream(), true);
                                  new serverInput(clientSocket).start();
                                  System.out.println("LOGIN " + userInfo[0] + " " + password);
                                  clientOutputSocket.println("LOGIN " + userInfo[0] + " " + password);

                            }else{
                                displayMessage(2, " El servidor no se encuentra registrado ", " ERROR TABLA SERVIDOR ");
                                loginView.userNameTb.setText("");
                                loginView.userPassTb.setText("");
                            }
                            baseDatos.close();
                        }catch(Exception error){
                            error.printStackTrace();
                        }
                  }
                });



        //mostrar las ventanas
            //ventana.show(contenedor,mainCard);
            //ventana.show(contenedor, serverCard);
            //ventana.show(contenedor, sendCard);
            ventana.show(contenedor, contactCard);
        //Parametros del frame principal
        interfaz.setDefaultCloseOperation(interfaz.EXIT_ON_CLOSE);
        interfaz.setLayout(new BorderLayout(10,10));
        interfaz.add(contenedor, BorderLayout.CENTER);
        interfaz.setSize(500,400);
        interfaz.setResizable(false);
        interfaz.setLocationRelativeTo(null);
        interfaz.setVisible(true);
      }
      //metodo para mostrar mensajes en la interfaz
      public static void displayMessage(int tipo, String titulo, String mensaje){
          switch (tipo){
              //mensaje tipo alerta
              case 1:
                    JOptionPane.showMessageDialog(null, titulo, mensaje, JOptionPane.WARNING_MESSAGE);
              break;
              //mensaje tipo Error
              case 2:
                    JOptionPane.showMessageDialog(null, titulo, mensaje, JOptionPane.ERROR_MESSAGE);
              break;
              //mensaje tipo normal
              case 3:
                    JOptionPane.showMessageDialog(null, titulo, mensaje, JOptionPane.INFORMATION_MESSAGE);
              break;
          }
      }
      //metodo para separar el nombre de usuario y del servidor
      public static String[] getUserServer(String username){
            String [] info = new String[2];
            Scanner scan = new Scanner(username);
            scan.useDelimiter("@");
            info[0] = scan.next();
            info[1] = scan.next();
            return info;
      }

//----------------------- clase que recibe los mensajes desde le servidor -----------------------------------
    public static class serverInput extends Thread{
          //campos de la clase
          Socket clientInputServer;
          //constructor de la clase
          public serverInput(Socket cliente){
              clientInputServer = cliente;
          }
          //metodo que recibe todos los inputs
          public void run(){
                  try{
                      BufferedReader clientInputSocket = new BufferedReader(new InputStreamReader(clientInputServer.getInputStream()));
                  //ciclo infinito
                      while (true){
                            String serverResponse = clientInputSocket.readLine();
                            if (serverResponse.equals("OK LOGIN")){

                            }else if (serverResponse.equals("LOGIN ERROR 101")){
                                  displayMessage(2, "unknown user","LOGIN ERROR 101");
                            }
                            System.out.println(serverResponse);
                      }
                  }catch(Exception error){
                      System.out.println("Error en lectura de datos desde el cliente");
                      error.printStackTrace();
                  }
          }
    }

}
