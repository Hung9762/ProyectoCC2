package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

public class login extends JPanel{
      //campos de la interfaz grafica
      public JPanel contenido, centro, sur;
      public JLabel txtUser, txtPassword, txtConfirm;
      public JButton homeBt, loginBt, clearBt;
      public JTextField userTb;
      public JPasswordField pass1Tb;
      //construcot de la clase login
      public login() throws IOException{
        //instancias de los botones
        homeBt = new JButton("Home", new ImageIcon("icons/home.png"));
        loginBt = new JButton("Login", new ImageIcon("icons/login.png"));
        clearBt = new JButton("Clear", new ImageIcon("icons/clear.png"));
        //instancias de los textos
        txtUser = new JLabel("Username: ");
        txtPassword = new JLabel("Password: ");
        //txtConfirm = new JLabel("Confirmacion password: ");
        //instancia de los textboxs
        userTb = new JTextField(8);
        pass1Tb = new JPasswordField(8);
        //pass2Tb = new JPasswordField(8);
        //instancia del panel central
        centro = new JPanel(new GridLayout(2,2));
        centro.add(txtUser);
        centro.add(userTb);
        centro.add(txtPassword);
        centro.add(pass1Tb);
        //centro.add(txtConfirm);
        //centro.add(pass2Tb);
        //instancia del panel sur
        sur = new JPanel();
        sur.add(homeBt);
        sur.add(loginBt);
        sur.add(clearBt);
        //panel principal
        contenido = new JPanel(new BorderLayout(10,10));
        contenido.add(centro, BorderLayout.CENTER);
        contenido.add(sur, BorderLayout.SOUTH);
        //frame principal
        this.setBorder(new EmptyBorder(130,10,10,10));
        //this.setBackground(new Color(50,50,0));
        this.add(contenido);

        clearBt.addActionListener((ActionEvent e) ->{
            
        });
      }
}
