package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.*;
import java.util.*;

public class home extends JPanel{
    //campos de la interfaz grafica de home
    public JPanel  contenido, centro, sur;
    public JButton serverBt, loginBt, signUpBt;
    JLabel logo;
    public home() throws IOException{
        //instancia del logo
        logo = new JLabel(new ImageIcon("logo.png"));
        //instancia de los botones
        serverBt = new JButton("Servidores", new ImageIcon("icons/cloud.png"));
        loginBt = new JButton("Login", new ImageIcon("icons/login.png"));
        signUpBt = new JButton("SignUp", new ImageIcon("icons/add.png"));
        //instancia del panel de los botones
        sur = new JPanel();
        sur.add(serverBt);
        sur.add(loginBt);
        sur.add(signUpBt);
        //instancia del panel central
        centro = new JPanel();
        centro.add(logo);
        //panel principal
        contenido = new JPanel(new BorderLayout(10,10));
        contenido.add(centro, BorderLayout.CENTER);
        contenido.add(sur, BorderLayout.SOUTH);
        //frame principal
        this.setBorder(new EmptyBorder(70,10,10,10));
        //this.setBackground(new Color(150,150,150));
        this.add(contenido);
    }

}
