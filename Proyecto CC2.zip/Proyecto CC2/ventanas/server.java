package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

public class server extends JPanel{
      //campos de la interfaz grafica
      public JPanel contenido, centro, sur;
      public JLabel txtServer, txtIp;
      public JButton homeBt, okBt, clearBt;
      public JTextField serverTb, ipTb;
      //construcot de la clase login
      public server() throws IOException{
        //instancias de los botones
        homeBt = new JButton("Home", new ImageIcon("icons/home.png"));
        okBt = new JButton("Registrar", new ImageIcon("icons/edit.png"));
        clearBt = new JButton("Clear", new ImageIcon("icons/clear.png"));
        //instancias de los textos
        txtServer = new JLabel("Server Name: ");
        txtIp = new JLabel("Ip Address: ");
        //instancia de los textboxs
        serverTb = new JTextField(10);
        ipTb = new JTextField(10);
        //instancia del panel central
        centro = new JPanel(new GridLayout(2,2));
        centro.add(txtServer);
        centro.add(serverTb);
        centro.add(txtIp);
        centro.add(ipTb);
        //instancia del panel sur
        sur = new JPanel();
        sur.add(homeBt);
        sur.add(okBt);
        sur.add(clearBt);
        //panel principal
        contenido = new JPanel(new BorderLayout(10,10));
        contenido.add(centro, BorderLayout.CENTER);
        contenido.add(sur, BorderLayout.SOUTH);
        //frame principal
        this.setBorder(new EmptyBorder(130,10,10,10));
        //this.setBackground(new Color(50,50,0));
        this.add(contenido);

        //programacion de los botones
        //accion del boton clear
        clearBt.addActionListener((ActionEvent e) ->{
              serverTb.setText("");
              ipTb.setText("");
        });
      }
}
