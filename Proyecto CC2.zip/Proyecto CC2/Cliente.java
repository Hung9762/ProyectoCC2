import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.util.Scanner;
import UGDB.*;

import ventanas.*;

public class Cliente{
    //campos
    public static final String homeCard = "home";
    public static final String loginCard = "login";
    public static final String serverCard = "server";
    JFrame interfaz;
    JPanel contenedor;
    CardLayout ventana;
    public static String  usuarioServidor, usuarioNombre, usuarioPassword, serverName, serverIp;
    DB baseDatos;
    //constructor
    public Cliente() throws IOException{
        interfaz = new JFrame("- Cliente -");
        ventana = new CardLayout();
        contenedor = new JPanel(ventana);
        home principal = new home();
        login loginView = new login();
        server serverView = new server();
        baseDatos = new DB("ClientServer");
        try{
              baseDatos.connect();
        }catch (Exception a){

        }

        //agregar al contenedor de ventanas
        contenedor.add(principal, homeCard);
        contenedor.add(loginView, loginCard);
        contenedor.add(serverView, serverCard);
//--------------------------------- mainCard ----------------------------------
        //boton para cambiar al panel de login
        principal.loginBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, loginCard);
            }
        });
        //boton para cambiar al panel de server
        principal.serverBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, serverCard);
            }
        });
//--------------------------------- LoginView ----------------------------------
        //boton para cambiar al panel de main
        loginView.homeBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, homeCard);
            }
        });
        //boton para obtener del usuario para el login
        loginView.loginBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                  //Comprobacion que los textboxs no esten vacios
                  if (loginView.userTb.getText().equals("") || loginView.pass1Tb.getPassword().length == 0){
                      JOptionPane.showMessageDialog(null, " No lleno todas las casillas ", " Error en ingresos de datos ",JOptionPane.WARNING_MESSAGE );
                  }else{
                        //metodo para obtener el nombre y servidor desde el username
                        String infoUser[] = getUserInfo(loginView.userTb.getText());
                        usuarioNombre = infoUser[0];
                        usuarioServidor = infoUser[1];
                        usuarioPassword = new String(loginView.pass1Tb.getPassword());
                        System.out.println(usuarioNombre);
                        System.out.println(usuarioServidor);
                        System.out.println(usuarioPassword);
                  }
            }
        });
//--------------------------------- Server ----------------------------------
        //boton para cambiar al panel main
        serverView.homeBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, homeCard);
            }
        });
        //boton para registrar el servidor a la base de datos del cliente
        serverView.okBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                  //comprobacion que los textboxs esten llenos
                  if (serverView.serverTb.getText().equals("") || serverView.ipTb.getText().equals("")){
                        JOptionPane.showMessageDialog(null, " No lleno todas las casillas ", " Error en ingresos de datos ",JOptionPane.WARNING_MESSAGE );
                  }else{
                        //busco si el servidor ya esta guardado
                        String query = "Select server FROM servidores";
                  }
                  //serverName = serverView.serverTb.getText();
                  //serverIp = serverView.ipTb.getText();

            }
        });

        //ventana.show(contenedor, homeCard);
        //ventana.show(contenedor, loginCard);
        //ventana.show(contenedor, serverCard);
        //opciones del frame principal
        interfaz.setDefaultCloseOperation(interfaz.EXIT_ON_CLOSE);
        interfaz.setLayout(new BorderLayout(10,10));
        interfaz.add(contenedor, BorderLayout.CENTER);
        //interfaz.getRootPane().setBorder(new EmptyBorder(5,5,5,5));
        //interfaz.getRootPane().setBackground(new Color(0,100,100));
        interfaz.setSize(500,400);
        //interfaz.pack();
        interfaz.setLocationRelativeTo(null);
        interfaz.setResizable(false);
        interfaz.setVisible(true);
    }

    //metodo Principal
    public static void main(String args []) throws IOException{
        new Cliente();

    }

    //metodo para separar el Username
    public static String[] getUserInfo(String username){
          Scanner sc = new Scanner(username);
          String info[] = new String [2];
          int count = 0;
          sc.useDelimiter("@");
            while (sc.hasNext()){
                info[count] = sc.next();
                count++;
            }
            return info;
    }
    //metodo para hacer queries
    public static boolean getInfoDB(DB base, String query){
        boolean result = false;
          try{
            result = base.executeNonQuery(query);
          }catch(Exception a){

          }
          return result;
    }

}
