import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;

import ventanas.*;

public class Cliente{
    //campos
    public static final String homeCard = "home";
    public static final String loginCard = "login";
    public static final String serverCard = "server";
    JFrame interfaz;
    JPanel contenedor;
    CardLayout ventana;
    //constructor
    public Cliente() throws IOException{
        interfaz = new JFrame("- Cliente -");
        ventana = new CardLayout();
        contenedor = new JPanel(ventana);

        home principal = new home();
        login loginView = new login();
        server serverView = new server();

        //agregar al contenedor de ventanas
        contenedor.add(principal, homeCard);
        contenedor.add(loginView, loginCard);
        contenedor.add(serverView, serverCard);

        //enventos de los botones de mainCard
        principal.loginBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, loginCard);
            }
        });
        principal.serverBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, serverCard);
            }
        });
        //enventos del botones login
        loginView.homeBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                ventana.show(contenedor, homeCard);
            }
        });
        loginView.loginBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                  //
            }
        });
        
        //ventana.show(contenedor, homeCard);
        //ventana.show(contenedor, loginCard);
        //ventana.show(contenedor, serverCard);
        //opciones del frame principal
        interfaz.setDefaultCloseOperation(interfaz.EXIT_ON_CLOSE);
        interfaz.setLayout(new BorderLayout(10,10));
        interfaz.add(contenedor, BorderLayout.CENTER);
        //interfaz.getRootPane().setBorder(new EmptyBorder(5,5,5,5));
        //interfaz.getRootPane().setBackground(new Color(0,100,100));
        interfaz.setSize(500,400);
        //interfaz.pack();
        interfaz.setLocationRelativeTo(null);
        interfaz.setResizable(false);
        interfaz.setVisible(true);
    }
    //metodo Principal
    public static void main(String args []) throws IOException{
        new Cliente();
    }

}
