import java.util.*;
import java.net.*;
import java.io.*;
import UGDB.*;
import java.util.Scanner;
public class DNS{
          private static Hashtable<Socket,String> logged = new Hashtable<Socket,String>();
          public static void main(String[] args) throws IOException{
                    ServerSocket listener = new ServerSocket(1200);
                    System.out.println("DNS en Linea ->");
                    ArrayList<Socket> sockets = new ArrayList<Socket>();
                    int i = 0;
                    try {
                        while (true) {
                                  sockets.add(listener.accept());
                                  new Recibos(sockets.get(i), i).start();
                                  i++;
                        }
                    }
                    finally {
                        listener.close();
                    }
          }
          private static class Recibos extends Thread {
                    private Socket jj;
                    private int numCliente;
                    public Recibos(Socket a, int b){
                              jj = a;
                              numCliente = b;
                    }
                    public void run(){
                              while (true) {
                                        try{
                                                 BufferedReader in = new BufferedReader(new InputStreamReader(jj.getInputStream()));
                                                 String input = in.readLine();
                                                 String[] arr = to(input);
                                                 if (input != null){
                                                        System.out.println(input);
                                                        enviar(arr,jj);
                                                 }
                                       }
                                       catch(Exception a){}
                             }
                    }
          }
          private static void enviar(String[] ll, Socket pp) throws IOException{
                    PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                   if (ll[0].equals("ONLINE") && (ll.length == 3) && (!logged.containsValue(ll[1]))){
                             DB conndb = new DB("dns.db");
                             try{
                                      conndb.connect();
                                      System.out.println("executing insert");
                                      String query = "INSERT INTO servidores (server, ip) VALUES ('"+ll[1]+"','"+ll[2]+"')";
                                      System.out.println(conndb.executeNonQuery(query));
                                      output.println("ONLINE" +ll[1]);
                                      conndb.close();
                             }
                             catch(Exception a){output.println(a);}
                   }
                   if (ll[0].equals("GETIPTABLE")) {

                             DB conndb = new DB("dns.db");
                             try{
                                       conndb.connect();
                                      if (conndb.executeQuery("select * from servidores ","rs1")) {
                                             while(conndb.next("rs1")){
                                                       System.out.println("DNS : OK IPTABLE "+conndb.getString("server","rs1")+" "+conndb.getString("ip","rs1"));
                                                       output.println("DNS : OK IPTABLE "+conndb.getString("server","rs1")+" "+conndb.getString("ip","rs1"));
                                             }
                                                       conndb.close();
                                     }
                                      else{
                                             output.println("ERROR");
                                      }
                             }
                             catch(Exception a){output.println(a);}
                   }
          }
          private static String[] to(String str){
                   Scanner sc = new Scanner(str);
                   Scanner sc1 = new Scanner(str);
                   int cont = 0;
                   while (sc.hasNext()){
                              cont++;
                              sc.next();
                   }
                   String[] arr = new String[cont];
                   for (int i = 0; i < cont; i++){
                              arr[i] = sc1.next();
                   }
                   return arr;
          }
}
