
public class Receiver{
	private String usuario;
	private String server;

	public Receiver(String usuario, String server){
		this.usuario = usuario;
		this.server = server;
	}

	public String getUsuario(){
		return usuario;
	}

	public String getServer(){
		return server;
	}
}
/*if (ll[0].equals("SEND") && ll[1].equals("MAIL")){
         oo = 1;
}
if ((oo == 1) && (ll[0].equals("MAIL") && ll[1].equals("TO")) && (!ll[ll.length-1].equals("*")) ) {
          Scanner sc = new Scanner(ll[2]);
          sc.useDelimiter("@");
          String user = sc.next();
          String serv = sc.next();
          Receiver receptor = new Receiver(user,serv);
          recep.add(receptor);

}
else if ((oo == 1) && (ll[0].equals("MAIL") && ll[1].equals("TO")) && (ll[ll.length-1].equals("*"))){
          Scanner sc = new Scanner(ll[2]);
          sc.useDelimiter("@");
          String user = sc.next();
          String serv = sc.next();
          Receiver receptor = new Receiver(user,serv);
          recep.add(receptor);
          oo= 2;
}
if ((oo == 2) && (ll[0].equals("MAIL")) && (ll[1].equals("SUBJECT"))) {
          String s ="";
          for (int i =2; i< ll.length; i++ ){
                    s =s+ ll[i]+ " ";
          }
          sub = s;
          oo = 3;
}
if ((oo == 3) && (ll[0].equals("MAIL")) && (ll[1].equals("BODY"))){
          String b ="";
        for (int i =2; i< ll.length; i++ ){
                  b =b+ ll[i]+ " ";
        }
        body = b;
        oo = 4;
}
if((oo == 4) && (ll[0].equals("END")) && (ll[1].equals("SEND")) && (ll[0].equals("MAIL")) ) {
          DB conndb = new DB("Mail.db");
          ArrayList<Receiver> goodRecipients = new ArrayList<Receiver>();
          for (int i = 0;i < recep.size() ;i++ ) {
                 try{
                           conndb.connect();
       if (conndb.executeQuery("select * from Contactos where usuarioid = '"+logged.get(pp)+"' AND usuario = '"+recep.get(i).getUsuario()+"' AND sid = "+recep.get(i).getServer(),"rs1")) {

                 try{
                           conndb.next("rs1");
                           if ((conndb.getString("usuario","rs1").equals(recep.get(i).getUsuario())) && (conndb.getString("sid","rs1").equals(recep.get(i).getServer()))) {
                                     goodRecipients.add(recep.get(i));
                           }
                 }catch(Exception e1){
                           System.out.println("Contacto no existe "+recep.get(i).getUsuario());
                 }
       }
       conndb.close();
}catch(Exception e){
                 System.out.println(e.getClass());
                 System.out.println(e.getMessage());
                 e.printStackTrace();
}
}
for (int i = 0;i < goodRecipients.size() ;i++ ) {
       System.out.println("usuario: "+goodRecipients.get(i).getUsuario()+" server: "+goodRecipients.get(i).getServer());
       try{
                 conndb.connect();
                 conndb.executeNonQuery("INSERT INTO Correos (sender,subject,body,usuario) VALUES ('"+logged.get(pp)+"','"+sub+"','"+body+"','"+goodRecipients.get(i).getUsuario()+"')");
                 conndb.close();
       }catch(Exception e){
                 e.printStackTrace();
       }

}
oo = 0;
}*/
