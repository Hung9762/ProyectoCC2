import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.util.*;
import java.util.Scanner;
import ventanas.*;
import java.net.*;
import UGDB.*;



public class client{
      //base de datos tabla de servidores
      //static DB baseDatos;
      //ventanas
      public static final String mainCard = "main";
      public static final String serverCard = "server";
      public static final String loginCard = "login";
      public static final String homeCard = "home";
      public static final String sendCard = "send";
      public static final String inboxCard = "inbox";
      public static final String contactCard = "contact";
      //campos de la intefaz grafica
      static JFrame interfaz;
      static JPanel contenedor;
      static CardLayout ventana;
      //Datos del usuario y servidor
      public static String userName, userServer, userPass, serverName, serverIp;
      //puerto de lectura y escritura
      BufferedReader clientInputSocket;
      PrintWriter clientOutputSocket;
      Socket clientSocket;
      //main
      public static void main(String args []){
          new client();
      }
      //constructor del la intefaz grafica
      public client(){
          iniciar_interfaz();
      }
      //constructo de la interfaz grafica
      public static void iniciar_interfaz(){
        //conexion con la base de datos de servidores disponibles
        DB baseDatos = new DB("serverList.db");
        try {
              baseDatos.connect();
        }catch (Exception error){
              System.out.println("Error en conexion de base de datos desde el cliente");
              error.printStackTrace();
        }
        //instancia del JFrame y del panel contenedor
          interfaz = new JFrame();
          ventana = new CardLayout();
          contenedor = new JPanel(ventana);

        //instancia de las clases de ventanadas disponibles
          main mainView = new main();
          server serverView = new server();

        //Adicion de la ventanas al CardLayout
          contenedor.add(mainView, mainCard);
          contenedor.add(serverView, serverCard);
//-------------- acciones de los botones de la ventana main --------------------
        //boton para ir a la ventana de registro de servidores
          mainView.serverBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                interfaz.setTitle(" Registro de servidores ");
                ventana.show(contenedor, serverCard);
            }
          });
        //boton para ir a la ventana de login del usuario
          mainView.loginBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                interfaz.setTitle(" Login ");
                //ventana.show(contenedor, loginCard);
            }
          });
//------------ acciones de los botones de la ventana server --------------------
        //boton para ir a la ventana main
          serverView.mainBt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                interfaz.setTitle("- Main -");
                ventana.show(contenedor, mainCard);
            }
          });
        //boton para registrar un servidor en la base de datos
        serverView.regBt.addActionListener(new ActionListener(){
          @Override
          public void actionPerformed(ActionEvent e){
                //comprobacion que los textboxs esten llenos
                if (serverView.serverNameTb.getText().equals("") || serverView.serverIpTb.getText().equals("")){
                      displayMessage(2, " No lleno todas las casillas", " ERROR INGRESO DATOS");
                }else{
                      //consultar a la base de datos si el servidor ya existe en la tabla
                      String query = "SELECT ip_address FROM Servidores WHERE servidor ='" + serverView.serverNameTb.getText() + "'";
                      //consulta la base de datos
                        try {
                            System.out.println(baseDatos.executeQuery(query,"rs"));
                            try{
                                baseDatos.next("rs");
                            }catch(Exception error){
                                error.printStackTrace();
                            }
                            System.out.println(baseDatos.getString("ip_address","rs"));
                            baseDatos.close();
                        }catch(Exception error){
                              error.printStackTrace();
                        }

                }
          }
        });



        //mostrar las ventanas
            //ventana.show(contenedor,mainCard);
            //ventana.show(contenedor, serverCard);
        //Parametros del frame principal
        interfaz.setDefaultCloseOperation(interfaz.EXIT_ON_CLOSE);
        interfaz.setLayout(new BorderLayout(10,10));
        interfaz.add(contenedor, BorderLayout.CENTER);
        interfaz.setSize(500,400);
        interfaz.setResizable(false);
        interfaz.setLocationRelativeTo(null);
        interfaz.setVisible(true);
      }
      //metodo para mostrar mensajes en la interfaz
      public static void displayMessage(int tipo, String titulo, String mensaje){
          switch (tipo){
              //mensaje tipo alerta
              case 1:
                    JOptionPane.showMessageDialog(null, titulo, mensaje, JOptionPane.WARNING_MESSAGE);
              break;
              //mensaje tipo Error
              case 2:
                    JOptionPane.showMessageDialog(null, titulo, mensaje, JOptionPane.ERROR_MESSAGE);
              break;
              //mensaje tipo normal
              case 3:
                    JOptionPane.showMessageDialog(null, titulo, mensaje, JOptionPane.INFORMATION_MESSAGE);
              break;
          }
      }


}
