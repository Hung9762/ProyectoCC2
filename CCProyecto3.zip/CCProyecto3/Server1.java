import java.util.*;
import java.net.*;
import java.io.*;
import UGDB.*;
import java.util.Scanner;
public class Server1{
          public static void main(String[] args) throws Exception {
                  ServerSocket listener = new ServerSocket(2000);
                  System.out.println("Server en Linea ->");
                  ArrayList<Socket> sockets = new ArrayList<Socket>();
                  int i = 0;
                  try {
                      while (true) {
                                sockets.add(listener.accept());
                                new Envios(sockets.get(i), i).start();
                                new Recibos(sockets.get(i), i).start();
                                i++;
                      }
                  } finally {
                      listener.close();
                  }
              }
              private static class Envios extends Thread{
                        private Socket pp;
                        private int numCliente;
                       BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                       String user = "TheSERVER";
                       public Envios(Socket a, int b) {
                                 pp = a;
                                 numCliente = b;
                       }
                       public void run(){
                                 try {
                                           PrintWriter output = new PrintWriter(pp.getOutputStream(), true);
                                           //output.println("Si desea salir escriba salir");
                                           output.println("Usted es el cliente "+ numCliente);
                                           while(true){
                                                     output.println(input.readLine());
                                           }
                                 } catch (IOException e) {
                                           System.out.println("Error con cliente# " + user + ": " + e);
                                 }
                       }
              }
              private static class Recibos extends Thread {
                        private Socket jj;
                        private int numCliente;
                        public Recibos(Socket a, int b){
                                  jj = a;
                                  numCliente = b;
                        }

                        public void run(){
                                  while (true) {
                                            try{
                                                      BufferedReader in = new BufferedReader(new InputStreamReader(jj.getInputStream()));
                                                      String input = in.readLine();
                                                      String[] arr = to(input);


                                           if (input != null){


                                                               //DB conndb = new DB("Correo.db");
                                                               try{
                                                                         //conndb.connect();
                                                                         //String query = "INSERT INTO conversaciones (Usuario, Mensaje) VALUES ('" + username + "', '" + input + "')";
                                                                         //System.out.println(conn.executeNonQuery(query));
                                                               }
                                                               catch(Exception a){System.out.println(a);}

                                                               System.out.println(input);
                                                               enviar(arr,jj);
                                                     }
                                           }
                                           catch(Exception a){}

                                 }
                        }

              }
              private static String[] to(String str){
                       Scanner sc = new Scanner(str);
                       Scanner sc1 = new Scanner(str);
                       int cont = 0;
                       while (sc.hasNext()){
                                 cont++;
                                 sc.next();
                       }
                       String[] arr = new String[cont];
                       for (int i = 0; i < cont; i++){
                                 arr[i] = sc1.next();
                       }
                       return arr;
             }
             private static boolean compilador(String[] str){

                       return false;
            }
             private static void enviar(String[] ll, Socket pp) throws IOException{
                       if (ll[0].equals("LOGIN") && (ll.length == 3)){
                                 PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                                 DB conndb = new DB("Mail.db");
                                 try{
                                           conndb.connect();
                                           String query = "Select * from Usuarios where usuario = '" + ll[1] +"' AND password = '" + ll[2]+"'";
                                           if (conndb.executeQuery(query, "rs1")){
                                                     if (conndb.getString("usuario","rs1") != null){
                                                            output.println("OK LOGIN");
                                                     }
                                                     else{
                                                               output.println("Usuario no existe");
                                                     }
                                           }
                                           else{
                                                  output.println("ERROR");
                                           }
                                 }
                                 catch(Exception a){
                                           //System.out.println(a);
                                           output.println("ERROR LOGIN");}

                       }
            }
}
