import java.net.*;
import java.io.*;
public class Cliente{
          public static void main(String[] args) throws IOException{
                    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                    Socket socket = new Socket("", 2000);
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    System.out.println("Que desea hacer?");
                    //String ip = input.readLine();
                    //System.out.println("Ingrese usuario");
                    //String user = input.readLine();
                    //out.println(user);
                    (new Recibos(socket)).start();
                    while(true){
                              String men = input.readLine();
                              out.println(men);
                              out.flush();
                    }

          }
          private static class Recibos extends Thread{
                    Socket socket;
                    public Recibos(Socket a){
                              socket = a;
                    }
                    public void run(){
                              try {
                                        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                        while(true){
                                                  String input = in.readLine();
                                                  if (input !=null){
                                                            System.out.println(input);
                                                  }

                                        }
                              } catch (IOException e) {

                              }
                    }
          }
}
