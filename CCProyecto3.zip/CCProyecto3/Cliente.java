import java.net.*;
import java.io.*;
import UGDB.*;
import java.util.Scanner;

public class Cliente{
          public static void main(String[] args) throws IOException{
                    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		Socket socket = new Socket("172.20.10.2", 1400);
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    System.out.println("Que desea hacer?");
                    (new RecibosCliente(socket)).start();
                    while(true){
                              String men = input.readLine();
                              out.println(men);
                              out.flush();
                    }

          }
          private static class RecibosCliente extends Thread{
                    Socket socket;
                    public RecibosCliente(Socket a){
                              socket = a;
                    }
                    public void run(){
                              try {
                                        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                                        while(true){
                                                  String input = in.readLine();
                                                  if (input !=null){
                                                            System.out.println(input);
                                                  }

                                        }
                              } catch (IOException e) {

                              }
                    }
          }
}
