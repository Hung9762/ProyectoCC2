import java.net.*;
import java.io.*;
import java.util.Scanner;
public class Server{
          public static void main(String[] args) throws IOException{
                    System.out.println("-> Server en linea");
                    ServerSocket lis = new ServerSocket(2000);
                    Socket jj = lis.accept();
                    (new Envios(jj)).start();
                              BufferedReader in = new BufferedReader(new InputStreamReader(jj.getInputStream()));
                              while (true) {
                                        String input = in.readLine();
                                        String[] arr = to(input);
                                        if (input != null){


                                                            //DB conndb = new DB("chat.db");
                                                            try{
                                                                      //conndb.connect();
                                                                      //String query = "INSERT INTO conversaciones (Usuario, Mensaje) VALUES ('" + username + "', '" + input + "')";
                                                                      //System.out.println(conn.executeNonQuery(query));
                                                            }
                                                            catch(Exception a){System.out.println(a);}

                                                            System.out.println(input);
                                                            System.out.println(arr[0]);
                                                  }

                              }
          }
          private static class Envios extends Thread{
                    private Socket pp;
                    BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                    String user = "TheSERVER";
                    public Envios(Socket a) {
                              pp = a;
                    }
                    public void run(){
                              try {
                                        PrintWriter output = new PrintWriter(pp.getOutputStream(), true);
                                        //output.println("Si desea salir escriba salir");
                                        output.println(user);
                                        while(true){
                                                  output.println(input.readLine());
                                        }
                              } catch (IOException e) {
                                        System.out.println("Error con cliente# " + user + ": " + e);
                              }
                    }
          }
          private static String[] to(String str){
                    Scanner sc = new Scanner(str);
                    Scanner sc1 = new Scanner(str);
                    int cont = 0;
                    while (sc.hasNext()){
                              cont++;
                              sc.next();
                    }
                    String[] arr = new String[cont];
                    for (int i = 0; i < cont; i++){
                              arr[i] = sc1.next();
                    }
                    return arr;
          }

}
