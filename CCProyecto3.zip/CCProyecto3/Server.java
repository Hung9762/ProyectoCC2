import java.util.*;
import java.net.*;
import java.io.*;
import UGDB.*;
import java.util.Scanner;
public class Server{
          private static Hashtable<Socket,String> logged = new Hashtable<Socket,String>();
          public static void main(String[] args) throws Exception {
                    (new Servidores()).start();
                  ServerSocket listener = new ServerSocket(1400);
                  System.out.println("Server en Linea ->");
                  ArrayList<Socket> sockets = new ArrayList<Socket>();
                  int i = 0;
                  try {
                      while (true) {
                                sockets.add(listener.accept());
                                new Recibos(sockets.get(i), i).start();
                                i++;
                      }
                  }
                  finally {
                      listener.close();
                  }
          }
          private static class Servidores extends Thread{
                    public void run(){
                              try{
                              (new Envios()).start();
                              ServerSocket lis = new ServerSocket(1500);
                              ArrayList<Socket> sockets = new ArrayList<Socket>();
                              int i = 0;
                              try {
                                  while (true) {
                                            sockets.add(lis.accept());
                                            new Recibos(sockets.get(i), i).start();
                                            i++;
                                  }
                              }
                              finally {
                                  lis.close();
                              }
                    } catch(Exception a){}
                    }
          }
          private static class Envios extends Thread{
                    public void run(){
                              try {
                              BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
                              Socket socket = new Socket("172.20.10.13", 1500);
                              PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                              System.out.println("Que desea hacer?");
                              while(true){
                                        String men = input.readLine();
                                        out.println(men);
                                        out.flush();
                              }
                              }
                              catch(Exception a){}
                    }
          }

              private static class Recibos extends Thread {
                        private Socket jj;
                        private int numCliente;
                        public Recibos(Socket a, int b){
                                  jj = a;
                                  numCliente = b;
                        }
                        public void run(){
                                  while (true) {
                                            try{
                                                     BufferedReader in = new BufferedReader(new InputStreamReader(jj.getInputStream()));
                                                     String input = in.readLine();
                                                     String[] arr = to(input);
                                                     if (input != null){
                                                            System.out.println(input);
                                                            if (arr[0].equals("SEND") && arr[1].equals("MAIL")){
                                                                      sendMail(jj);
                                                            }
                                                            enviar(arr,jj);
                                                     }
                                           }
                                           catch(Exception a){}
                                 }
                        }
              }
//----------------------------- METODOS ------------------------------------------
             private static String[] to(String str){
                       Scanner sc = new Scanner(str);
                       Scanner sc1 = new Scanner(str);
                       int cont = 0;
                       while (sc.hasNext()){
                                 cont++;
                                 sc.next();
                       }
                       String[] arr = new String[cont];
                       for (int i = 0; i < cont; i++){
                                 arr[i] = sc1.next();
                       }
                       return arr;
              }
             private static boolean compilador(String[] str){

                       return false;
             }
             private static void enviar(String[] ll, Socket pp) throws IOException{
                       if (ll[0].equals("LOGIN") && (ll.length == 3) && (!logged.containsValue(ll[1]))){
                                 PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                                 DB conndb = new DB("Mail.db");
                                 try{
                                           conndb.connect();
                                           String query = "Select * from Usuarios where usuario = '" + ll[1] +"' AND password = '" + ll[2]+"'";
                                           if (conndb.executeQuery(query, "rs1")){
                                                     if (conndb.getString("usuario","rs1") != null){
                                                            output.println("OK LOGIN");
                                                            logged.put(pp,ll[1]);
                                                            conndb.close();

                                                     }
                                                     else{
                                                               output.println("Usuario no existe");
                                                     }
                                           }
                                           else{
                                                  output.println("ERROR");
                                           }
                                 }
                                 catch(Exception a){
                                           //System.out.println(a);
                                           output.println("ERROR LOGIN");}

                       }
                       if (ll[0].equals("CLIST") && (ll.length == 2)&& (logged.get(pp).equals(ll[1]))){
                                 PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                                 DB conndb = new DB("Mail.db");
                                 try{
                                           conndb.connect();
                                           if (conndb.executeQuery("select * from Contactos where usuarioid = '"+ll[1]+"'","rs1")) {
                                          	while(conndb.next("rs1")){
                                                            output.println("Server : OK CLIST "+conndb.getString("usuario","rs1")+"@"+conndb.getString("sid","rs1"));
                                                  }
                                                            conndb.close();

                                          }
                                           else{
                                                  output.println("ERROR");
                                           }
                                 }
                                 catch(Exception a){
                                           System.out.println(a);
                                           output.println("ERROR Clist");}

                       }
                       if (ll[0].equals("NEWCONT") && (ll.length == 2)){
                               boolean serverExist = false;
            		 boolean userExist = false;
                               PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                               DB conndb = new DB("Mail.db");
                               try{

                                        conndb.connect();
                                        Scanner sc = new Scanner(ll[1]);
                                        sc.useDelimiter("@");
                                        String user = sc.next();
                                        String serv = sc.next();
                                        if (conndb.executeQuery("select usuario from Usuarios","rs1")) {
                                        while(conndb.next("rs1")){
                                                                                String usuariosExistentes = conndb.getString("usuario","rs1").toString();
                                                                                if (logged.get(pp).equals(usuariosExistentes)) {
                                                                                          userExist = true;
                                                                                }
                                                                      }
                                                                      conndb.close();
                                                                      if(!userExist){
                                                  System.out.println("====> ERROR, EL USUARIO AL QUE LE DESEA AGREGAR EL CONTACTO NO EXISTE");
                                                                                return;
                                        }
                                        }
                                        conndb.connect();
                                        if (conndb.executeQuery("select sid from Server","rs2")) {
                                                                      while(conndb.next("rs2")){
                                                                                String serversGuardados = conndb.getString("sid","rs2").toString();
                                                                                if (serv.equals(serversGuardados)) {
                                                                                          serverExist = true;
                                                                                }
                                                                      }
                                                                      conndb.close();
                                                                      conndb.connect();
                                                                      if (serverExist) {
                                                                                System.out.println("executing insert");
                                                                                String query = "INSERT INTO Contactos (usuario,sid,usuarioid) VALUES ('"+user+"','"+serv+"','"+logged.get(pp)+"')";
                                                                          System.out.println(conndb.executeNonQuery(query));
                                                                          output.println("OK NEWCONT " +ll[1]);
                                                                          conndb.close();
                                                                      }
                                                                      else{
                                                                                System.out.println("====> ERROR, EL SERVIDOR AL QUE PERTENECE NO EXISTE");
                                                                                return;
                                                                      }
                                        }
                               }
                               catch(Exception a){output.println(a);}
                       }
                       if (ll[0].equals("GETNEWMAILS") && (ll.length == 2)){
                                 PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                                  DB conndb = new DB("Mail.db");
                                  try{
                                            conndb.connect();
                                            if (conndb.executeQuery("select * from Correos where usuario = '"+ll[1]+"'","rs1")) {
            	                                         while(conndb.next("rs1"))
            		                                              output.println("Server : OK GETNEWMAILS "+conndb.getString("sender","rs1")+" \""+conndb.getString("subject","rs1")+"\" \""+conndb.getString("body","rs1")+"\"");
                                                                 }
                                  }
                                  catch(Exception a){}
                       }
                       if (ll[0].equals("LOGOUT") && (ll.length == 1) && (logged.containsKey(pp))){
                                 PrintWriter output= new PrintWriter(pp.getOutputStream(), true);
                                 logged.remove(pp);
                                 try{
                                           output.println("OK LOGOUT");
                                 }
                                 catch(Exception a){}
                       }
             }
             private static void sendMail(Socket pp) throws IOException{
                       BufferedReader in = new BufferedReader(new InputStreamReader(pp.getInputStream()));
                       ArrayList<String> recep = new ArrayList<String>();
                       ArrayList<String> buenos = new ArrayList<String>();
                       String sub = "";
                       String body = "";
                       DB conndb = new DB("Mail.db");
                       String input = in.readLine();
                       System.out.println("todo va bien");
                       while(!input.equals("END SEND MAIL")){
                                 String[] ll = to(input);
                                 if ((ll[0].equals("MAIL") && ll[1].equals("TO")) && (!ll[ll.length-1].equals("*"))){
                                           recep.add(ll[2]);
                                           System.out.println(input);
                                 }
                                 else if ((ll[0].equals("MAIL") && ll[1].equals("TO")) && (ll[ll.length-1].equals("*"))){
                                           recep.add(ll[2]);
                                           System.out.println(input);
                                 }
                                 else if((ll[0].equals("MAIL")) && (ll[1].equals("SUBJECT"))){
                                           sub = input.substring(12,input.length());
                                           System.out.println(input);
                                 }
                                 else if ((ll[0].equals("MAIL")) && (ll[1].equals("BODY"))){
                                           body = input.substring(9,input.length());
                                           System.out.println(input);
                                 }
                                 else {
                                            System.out.println("Se ha cerrado");
                                           break;

                                 }
                                 input = in.readLine();
                       }
                       System.out.println("todo va bien");
                       for(int i = 0; i < recep.size(); i++){
                                 Scanner sc = new Scanner(recep.get(i));
                                 sc.useDelimiter("@");
                                 String user = sc.next();
                                 String serv = sc.next();
                                 try{
                                           conndb.connect();
                                           try{
                                           if (conndb.executeQuery("select * from Contactos where usuarioid = '"+logged.get(pp)+"' AND usuario = '"+user+"' AND sid = '"+serv+"'","rs1")) {
                                                               conndb.next("rs1");
                                                               if ((conndb.getString("usuario","rs1").equals(user)) && (conndb.getString("sid","rs1").equals(serv))) {
                                                                         buenos.add(recep.get(i));
                                                               }
                                          }
                                } catch(Exception a){System.out.println(a);}
                                          conndb.close();
                                 }
                                 catch(Exception a){}
                       }
                       System.out.println("todo va bien");
                       for(int i = 0; i < buenos.size(); i++){
                                 Scanner sc = new Scanner(buenos.get(i));
                                 sc.useDelimiter("@");
                                 String user = sc.next();
                                 String serv = sc.next();
                                 try{
                                          conndb.connect();
                                          conndb.executeNonQuery("INSERT INTO Correos (sender,subject,body,usuario) VALUES ('"+logged.get(pp)+"','"+sub+"','"+body+"','"+user+"')");
                                          conndb.close();
                                }catch(Exception e){
                                          e.printStackTrace();
                                }
                       }
                       System.out.println("todo va bien");
             }
}
