package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.*;
import java.util.*;

public class contact extends JPanel{
  //campos de la ventana
    JPanel contenedor;
    GridBagLayout layout;
    GridBagConstraints limite;
    public JButton sendBt, clearBt, contactBt, smailBt;
    public JTextField asuntoTb;

    //constructor
    public contact(){
      //inicializacion del layout
          layout = new GridBagLayout();
          layout.columnWidths = new int[]{0, 0};
          layout.rowHeights = new int[]{0, 0};
          layout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
          layout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
          this.setLayout(layout);
      //inicializacion del jpanel
          contenedor = new JPanel();
          contenedor.setLayout(null);
          limite = new GridBagConstraints();
          limite.fill = GridBagConstraints.BOTH;
          limite.gridx = 0;
          limite.gridy = 0;
      //instancia de los textbox
          asuntoTb  = new JTextField(10);
          asuntoTb.setBounds(137, 276, 338, 26);
          contenedor.add(asuntoTb);
      //instancia de los botones
          clearBt = new JButton("Clear", new ImageIcon("Icons/clear.png"));
          clearBt.setBounds(335, 325, 110, 44);
          contenedor.add(clearBt);
          sendBt = new JButton("Registrar", new ImageIcon("Icons/register.png"));
          sendBt.setBounds(145, 325, 110, 44);
          contenedor.add(sendBt);
          contactBt = new JButton(new ImageIcon("Icons/send.png"));
          contactBt.setBounds(30, 80, 60, 60);
          contenedor.add(contactBt);
          smailBt = new JButton(new ImageIcon("Icons/inbox.png"));
          smailBt.setBounds(30, 180, 60, 60);
          contenedor.add(smailBt);
          JLabel mainTxt = new JLabel("Contact");
          mainTxt.setFont(new Font(mainTxt.getName(),Font.PLAIN, 22));
          mainTxt.setBounds(135, 5, 280, 45);
          contenedor.add(mainTxt);
          JLabel nameTxt = new JLabel("Username: ");
          nameTxt.setBounds(137, 248, 80, 16);
          contenedor.add(nameTxt);



      //agrego el Jpanel al frame principal
         this.add(contenedor, limite);
      //accion del boton de clearBt
         clearBt.addActionListener((ActionEvent e) ->{
            asuntoTb.setText("");
         });

    }
}
