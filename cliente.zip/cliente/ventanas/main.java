package ventanas;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.imageio.*;
import java.util.*;

public class main extends JPanel{
      //campos de la ventana
        JPanel contenedor;
        public JButton serverBt, loginBt;
        GridBagLayout layout;
        GridBagConstraints limite;
      //constructor de la clase e interfaz
      public main(){
      //inicializacion del layout
          layout = new GridBagLayout();
		      layout.columnWidths = new int[]{0, 0};
		      layout.rowHeights = new int[]{0, 0};
		      layout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		      layout.rowWeights = new double[]{1.0, Double.MIN_VALUE};
          this.setLayout(layout);
      //inicializacion del jpanel
          contenedor = new JPanel();
          contenedor.setLayout(null);
          limite = new GridBagConstraints();
          limite.fill = GridBagConstraints.BOTH;
		      limite.gridx = 0;
		      limite.gridy = 0;
      //campos de los botones
      //---- campo del boton de registro de servidores
        serverBt = new JButton(" Servidores ",new ImageIcon("Icons/server.png"));
        serverBt.setBounds(180, 30, 135, 50);
        contenedor.add(serverBt);
      //---- campo del boton para hacer login con el servidor
        loginBt = new JButton(" Login ",new ImageIcon("Icons/login.png"));
        loginBt.setBounds(330, 30, 135, 50);
        contenedor.add(loginBt);
      //agrego el Jpanel al frame principal
        this.add(contenedor, limite);
      }
}
