import java.net.*;
import java.io.*;

public class server{

    public static void main(String args[]) throws IOException {
          DB baseDatos = new DB("mensajes.db");
          BufferedReader inputServerUser = new BufferedReader(new InputStreamReader(System.in)); //input de usuario del servidor
          String serverName = getServerName(inputServerUser);
          Socket cliente; //socket del cliente
          String nombreCliente;
          System.out.println("-> Servidor en linea...");
          ServerSocket servidor = new ServerSocket(2000); //Instancia del puerto de entrada del servidor
          BufferedReader inputServer; //entrada de los mensajes desde el cliente
          PrintWriter outputServer; //salida de los mensajes desde el servidor
          try{
                if (!baseDatos.connect()){
                      System.out.println("Error en base de datos"+baseDatos.getError());
                      System.exit(0);
                }

                cliente = servidor.accept();
                inputServer = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
                outputServer = new PrintWriter(cliente.getOutputStream(),true);
                nombreCliente = inputServer.readLine(); //lee el nombre del cliente
                outputServer.println(serverName); //envio el nombre del servidor
                log(nombreCliente, "nombre del cliente");
                      while (true){
                          System.out.print("-> Ingrese mensaje a enviar: ");
                          String msg = inputServerUser.readLine();
                          //insert into table
                          System.out.println(baseDatos.executeNonQuery("INSERT INTO mensajes (usuario,mensaje) VALUES ('"+serverName+"','"+msg+"')"));
                          outputServer.println(msg);
                          String msgCliente = inputServer.readLine();
                          //insert into table
                          System.out.println(baseDatos.executeNonQuery("INSERT INTO mensajes (usuario,mensaje) VALUES ('"+nombreCliente+"','"+msgCliente+"')"));
                          log(msgCliente, nombreCliente);
                      }
          }catch(Exception e){
              System.out.println(e.getClass());
              System.out.println(e.getMessage());
          }
    }
    //metodo para ingresar el nombre del usuario del lado del servidor
    public static String getServerName(BufferedReader input) throws IOException{
      System.out.print("-> Ingrese el nombre de su usuario: ");
      String name = input.readLine();
      return name;
    }
    //metodo para imprimir mensajes
    public static void log(String mensaje, String usuario){
        System.out.println(usuario + ": " + mensaje);
    }
//fin del main
}
