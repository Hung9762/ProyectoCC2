import java.net.*;
import java.io.*;

public class cliente{
      public static void main(String args[]) throws IOException{
        BufferedReader userClienteInput = new BufferedReader (new InputStreamReader(System.in));
        String userName = getUserName(userClienteInput);
        //conexion con el servidor
        String servidorIp = "192.168.1.10"; //Ip del servidor
        Socket cliente = new Socket(servidorIp, 2000); //conexion con el servidor
        System.out.println("-> Cliente en linea ...");
        BufferedReader clienteInput = new BufferedReader(new InputStreamReader(cliente.getInputStream())); //salida del usuario
        PrintWriter clienteOutput = new PrintWriter(cliente.getOutputStream(),true); //entrada de mensajes desde el servidor
        String serverName;
        //envio del nombre del usuario al servidor
        try{
          clienteOutput.println(userName); //envio el nombre como el primer mensaje para que el servidor lo guarde
          serverName = clienteInput.readLine();
          log(serverName, " nombre del servidor");
              while (true){
                  log(clienteInput.readLine(), serverName);
                  System.out.print("-> Ingrese mansaje a enviar: ");
                  String msg = userClienteInput.readLine();
                  clienteOutput.println(msg);
              }
        }catch(IOException e){
        }
      }
      //metodo para obtener el nombre del usuario
      public static String getUserName(BufferedReader input) throws IOException{
        System.out.print("-> Ingrese el nombre de su usuario: ");
        String name = input.readLine();
        return name;
      }
      //metodo para imprimir mensajes
      public static void log(String mensaje, String usuario){
          System.out.println(usuario + ": " + mensaje);
      }
}
